# You can add extra resources in this directory for hexdoc to load.
# For example, hexdoc uses this for translations which are only needed for the web book.
