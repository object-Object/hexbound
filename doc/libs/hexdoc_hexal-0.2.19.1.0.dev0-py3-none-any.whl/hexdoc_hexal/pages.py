from hexdoc.patchouli.page import Page


class EverbookEntryPage(Page, type="hexcasting:everbook_entry"):
    pass


class EverbookEntryPage_0_2_x(
    Page,
    type="hexal:everbook_entry",
    template_type="hexcasting:everbook_entry",
):
    pass
